"""
Автопереводчик описаний модов для лаунчера Modrinth App (Windows / WebView2).

Установка:   pip install websocket-client
Запуск:      сначала запусти лаунчер через start_modrinth_translated.bat
             (он включает порт отладки), затем этот скрипт:
             python modrinth_app_translator.py ru
"""
import json
import os
import sys
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import websocket  # pip install websocket-client

# при запуске через pythonw нет консоли, print не должен падать
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")

PORT = 9222
LANG = sys.argv[1] if len(sys.argv) > 1 else "ru"

# ---------------- JS, который внедряется в лаунчер ----------------
JS = r"""
(() => {
  if (window.__mtLoaded) return;
  window.__mtLoaded = true;
  const LANG = '__LANG__';
  const SEL = '.markdown-body, .markdown, [class*="markdown"]';
  const SKIP = new Set(['CODE','PRE','KBD','SCRIPT','STYLE','SAMP','TEXTAREA']);
  const pending = new Map();
  const cache = new Map();
  const originals = new WeakMap();
  let nextId = 1;
  let auto = true;

  window.__mtResolve = (id, text, err) => {
    const p = pending.get(id);
    if (!p) return;
    pending.delete(id);
    err ? p.rej(new Error(err)) : p.res(text);
  };

  function tr(text) {
    if (cache.has(text)) return Promise.resolve(cache.get(text));
    return new Promise((res, rej) => {
      const id = nextId++;
      pending.set(id, { res: (t) => { cache.set(text, t); res(t); }, rej });
      window.mtTranslate(JSON.stringify({ id, text }));
    });
  }

  function findContainers() {
    let list = [...document.querySelectorAll(SEL)];
    list = list.filter((el) => !list.some((o) => o !== el && o.contains(el)));
    if (list.length) return list;
    // запасной вариант: родитель с наибольшим числом абзацев <p>
    const counts = new Map();
    document.querySelectorAll('p').forEach((p) => {
      const par = p.parentElement;
      if (par) counts.set(par, (counts.get(par) || 0) + 1);
    });
    let best = null, max = 1;
    counts.forEach((c, el) => { if (c > max) { max = c; best = el; } });
    return best ? [best] : [];
  }

  function textNodes(root) {
    const out = [];
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!/\p{L}/u.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        for (let p = n.parentElement; p && p !== root; p = p.parentElement) {
          if (SKIP.has(p.tagName)) return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (w.nextNode()) out.push(w.currentNode);
    return out;
  }

  async function translate(el) {
    if (el.dataset.mt === 'busy') return;
    el.dataset.mt = 'busy';
    updateBtn();
    const nodes = textNodes(el);
    await Promise.all(nodes.map(async (n) => {
      const src = n.nodeValue;
      if (!originals.has(n)) originals.set(n, src);
      const core = src.trim();
      if (!core) return;
      const lead = src.match(/^\s*/)[0];
      const trail = src.match(/\s*$/)[0];
      try { n.nodeValue = lead + (await tr(core)) + trail; } catch (e) { console.warn('[MT]', e); }
    }));
    el.dataset.mt = 'done';
    updateBtn();
  }

  function restore(el) {
    textNodes(el).forEach((n) => { if (originals.has(n)) n.nodeValue = originals.get(n); });
  }

  const start = () => {
    const btn = document.createElement('button');
    btn.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99999;padding:10px 14px;' +
      'border-radius:12px;border:0;cursor:pointer;font:600 14px system-ui,sans-serif;color:#fff;' +
      'background:#1bd96a;box-shadow:0 4px 14px rgba(0,0,0,.35);display:none';
    document.body.appendChild(btn);

    window.updateBtn = () => {
      const list = findContainers();
      if (!list.length) { btn.style.display = 'none'; return; }
      btn.style.display = 'block';
      const st = list[0].dataset.mt;
      btn.textContent = st === 'busy' ? '⏳ Перевожу…' :
                        st === 'done' ? '↩ Показать оригинал' : '🌐 Перевести (' + LANG + ')';
    };

    btn.onclick = async () => {
      const list = findContainers();
      if (!list.length) return;
      if (list[0].dataset.mt === 'done') {
        list.forEach((el) => { restore(el); el.dataset.mt = 'off'; });
        updateBtn();
      } else if (list[0].dataset.mt !== 'busy') {
        for (const el of list) await translate(el);
      }
    };

    let timer = null;
    const scan = () => {
      updateBtn();
      if (!auto) return;
      findContainers().forEach((el) => {
        if (!el.dataset.mt && el.textContent.trim()) translate(el);
      });
    };
    new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(scan, 600); })
      .observe(document.body, { childList: true, subtree: true });
    scan();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
""".replace("__LANG__", LANG)


# ---------------- Перевод на стороне Python ----------------
def google_translate(text: str) -> str:
    url = (
        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&dt=t&tl="
        + urllib.parse.quote(LANG)
    )
    data = urllib.parse.urlencode({"q": text}).encode()
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        j = json.load(r)
    return "".join(s[0] for s in j[0] if s[0])


# ---------------- CDP-подключение к лаунчеру ----------------
def find_page_ws():
    deadline = time.time() + 90  # ждём лаунчер не дольше 90 секунд
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json", timeout=3) as r:
                targets = json.load(r)
            pages = [t for t in targets if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]
            if pages:
                return pages[0]["webSocketDebuggerUrl"]
        except Exception:
            pass
        print("Жду запуск лаунчера с портом отладки…")
        time.sleep(2)
    sys.exit("Лаунчер не найден, выхожу.")


def main():
    ws_url = find_page_ws()
    ws = websocket.create_connection(ws_url, timeout=None, suppress_origin=True)
    lock = threading.Lock()
    counter = [0]

    def send(method, params=None):
        with lock:
            counter[0] += 1
            ws.send(json.dumps({"id": counter[0], "method": method, "params": params or {}}))

    send("Runtime.enable")
    send("Page.enable")
    send("Runtime.addBinding", {"name": "mtTranslate"})
    send("Page.addScriptToEvaluateOnNewDocument", {"source": JS})
    send("Runtime.evaluate", {"expression": JS})
    print(f"Переводчик подключён к лаунчеру (язык: {LANG}). Окно можно свернуть.")

    pool = ThreadPoolExecutor(max_workers=6)

    def handle(payload: str):
        req = json.loads(payload)
        rid = req["id"]
        try:
            res = google_translate(req["text"])
            expr = f"window.__mtResolve({rid}, {json.dumps(res)})"
        except Exception as e:
            expr = f"window.__mtResolve({rid}, null, {json.dumps(str(e))})"
        send("Runtime.evaluate", {"expression": expr})

    while True:
        try:
            msg = json.loads(ws.recv())
        except Exception:
            print("Лаунчер закрыт, выхожу.")
            break
        if msg.get("method") == "Runtime.bindingCalled" and msg["params"].get("name") == "mtTranslate":
            pool.submit(handle, msg["params"]["payload"])


if __name__ == "__main__":
    main()
