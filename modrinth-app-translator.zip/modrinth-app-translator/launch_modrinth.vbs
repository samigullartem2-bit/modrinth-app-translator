' Запускает Modrinth App с включённым переводчиком (без окон консоли).
Const LANG_CODE = "ru"
' Если скрипт не нашёл лаунчер сам, впиши сюда полный путь к exe, например:
' Const CUSTOM_EXE = "D:\Games\Modrinth App\Modrinth App.exe"
Const CUSTOM_EXE = ""

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)

local = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")
pf = sh.ExpandEnvironmentStrings("%ProgramFiles%")
pf86 = sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%")

candidates = Array( _
  CUSTOM_EXE, _
  local & "\Modrinth App\Modrinth App.exe", _
  local & "\Programs\Modrinth App\Modrinth App.exe", _
  local & "\Programs\ModrinthApp\Modrinth App.exe", _
  pf & "\Modrinth App\Modrinth App.exe", _
  pf86 & "\Modrinth App\Modrinth App.exe")

exe = ""
For Each c In candidates
  If c <> "" Then
    If fso.FileExists(c) Then
      exe = c
      Exit For
    End If
  End If
Next

If exe = "" Then
  MsgBox "Не нашёл Modrinth App. Открой файл launch_modrinth.vbs в блокноте и впиши путь к лаунчеру в CUSTOM_EXE.", 16, "Modrinth translator"
  WScript.Quit 1
End If

sh.Environment("Process")("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS") = "--remote-debugging-port=9222 --remote-allow-origins=*"
sh.Run """" & exe & """", 1, False
sh.Run "pyw """ & dir & "\modrinth_app_translator.py"" " & LANG_CODE, 0, False
