$dir = $PSScriptRoot
$desktop = [Environment]::GetFolderPath('Desktop')
$s = (New-Object -ComObject WScript.Shell).CreateShortcut("$desktop\Modrinth App (RU).lnk")
$s.TargetPath = "wscript.exe"
$s.Arguments = "`"$dir\launch_modrinth.vbs`""
$s.WorkingDirectory = $dir
$s.IconLocation = "$env:LOCALAPPDATA\Modrinth App\Modrinth App.exe"
$s.Save()
Write-Host "Ярлык создан на рабочем столе: Modrinth App (RU)"
