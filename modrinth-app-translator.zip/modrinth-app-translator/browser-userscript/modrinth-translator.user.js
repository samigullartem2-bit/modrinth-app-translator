// ==UserScript==
// @name         Modrinth Auto Translator
// @namespace    modrinth-auto-translator
// @version      1.0.0
// @description  Переводит описания модов (и список изменений) на Modrinth через Google Translate
// @match        https://modrinth.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @connect      translate.googleapis.com
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  // ---------- Настройки ----------
  let targetLang = GM_getValue('targetLang', 'ru'); // язык перевода
  let autoMode = GM_getValue('autoMode', true);     // переводить автоматически
  const CONCURRENCY = 5;                            // параллельных запросов
  const SELECTOR = '.markdown-body';                // контейнер описания на Modrinth
  const SKIP_TAGS = new Set(['CODE', 'PRE', 'KBD', 'SCRIPT', 'STYLE', 'SAMP', 'TEXTAREA']);

  GM_registerMenuCommand('Язык перевода…', () => {
    const v = prompt('Код языка (ru, uk, en, de, es, pl, zh-CN ...):', targetLang);
    if (v && v.trim()) {
      targetLang = v.trim();
      GM_setValue('targetLang', targetLang);
      cache.clear();
      document.querySelectorAll(SELECTOR).forEach((el) => { restore(el); delete el.dataset.mt; });
      updateButton();
      if (autoMode) scan();
    }
  });
  GM_registerMenuCommand('Автоперевод вкл/выкл', () => {
    autoMode = !autoMode;
    GM_setValue('autoMode', autoMode);
    alert('Автоперевод: ' + (autoMode ? 'включён' : 'выключен'));
    updateButton();
    if (autoMode) scan();
  });

  // ---------- Перевод ----------
  const cache = new Map();
  const originals = new WeakMap(); // textNode -> исходный текст

  function gtranslate(text) {
    const key = targetLang + '|' + text;
    if (cache.has(key)) return Promise.resolve(cache.get(key));
    return new Promise((resolve, reject) => {
      GM_xmlhttpRequest({
        method: 'POST',
        url: 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&dt=t&tl=' +
             encodeURIComponent(targetLang),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        data: 'q=' + encodeURIComponent(text),
        timeout: 15000,
        onload: (r) => {
          try {
            const json = JSON.parse(r.responseText);
            const out = json[0].map((s) => s[0]).join('');
            cache.set(key, out);
            resolve(out);
          } catch (e) { reject(e); }
        },
        onerror: reject,
        ontimeout: () => reject(new Error('timeout')),
      });
    });
  }

  async function runPool(items, worker) {
    let i = 0;
    const runners = Array.from({ length: CONCURRENCY }, async () => {
      while (i < items.length) {
        const idx = i++;
        try { await worker(items[idx]); } catch (e) { console.warn('[MT] ошибка перевода', e); }
      }
    });
    await Promise.all(runners);
  }

  function collectTextNodes(root) {
    const nodes = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!/\p{L}/u.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        for (let p = n.parentElement; p && p !== root; p = p.parentElement) {
          if (SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
  }

  async function translateContainer(el) {
    if (el.dataset.mt === 'busy') return;
    el.dataset.mt = 'busy';
    updateButton();
    const nodes = collectTextNodes(el);
    await runPool(nodes, async (node) => {
      const src = node.nodeValue;
      if (!originals.has(node)) originals.set(node, src);
      // сохраняем пробелы по краям, чтобы вёрстка не слипалась
      const lead = src.match(/^\s*/)[0];
      const trail = src.match(/\s*$/)[0];
      const core = src.trim();
      if (!core) return;
      const res = await gtranslate(core);
      node.nodeValue = lead + res + trail;
    });
    el.dataset.mt = 'done';
    updateButton();
  }

  function restore(el) {
    collectTextNodes(el).forEach((n) => {
      if (originals.has(n)) n.nodeValue = originals.get(n);
    });
    // узлы с переведённым текстом всё ещё содержат буквы, так что collectTextNodes их находит
  }

  // ---------- Кнопка ----------
  const btn = document.createElement('button');
  btn.style.cssText = [
    'position:fixed', 'right:16px', 'bottom:16px', 'z-index:99999',
    'padding:10px 14px', 'border-radius:12px', 'border:0', 'cursor:pointer',
    'font:600 14px system-ui,sans-serif', 'color:#fff', 'background:#1bd96a',
    'box-shadow:0 4px 14px rgba(0,0,0,.35)', 'display:none',
  ].join(';');
  document.body.appendChild(btn);

  function containers() { return [...document.querySelectorAll(SELECTOR)]; }

  function updateButton() {
    const list = containers();
    if (!list.length) { btn.style.display = 'none'; return; }
    btn.style.display = 'block';
    const st = list[0].dataset.mt;
    if (st === 'busy') btn.textContent = '⏳ Перевожу…';
    else if (st === 'done') btn.textContent = '↩ Показать оригинал';
    else btn.textContent = '🌐 Перевести (' + targetLang + ')';
  }

  btn.addEventListener('click', async () => {
    const list = containers();
    if (!list.length) return;
    if (list[0].dataset.mt === 'done') {
      list.forEach((el) => { restore(el); el.dataset.mt = 'off'; });
      updateButton();
    } else if (list[0].dataset.mt !== 'busy') {
      for (const el of list) await translateContainer(el);
    }
  });

  // ---------- Автоперевод для SPA ----------
  let timer = null;
  function scan() {
    updateButton();
    if (!autoMode) return;
    containers().forEach((el) => {
      if (!el.dataset.mt && el.textContent.trim().length > 0) translateContainer(el);
    });
  }

  new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(scan, 600);
  }).observe(document.body, { childList: true, subtree: true });

  scan();
})();
