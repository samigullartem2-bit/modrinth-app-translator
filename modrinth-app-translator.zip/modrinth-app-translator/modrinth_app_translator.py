"""
Автопереводчик описаний модов для лаунчера Modrinth App (Windows / WebView2).

Запуск: через launch_modrinth.vbs (он сам включает порт отладки и стартует этот скрипт).
Ручной запуск для отладки:  py modrinth_app_translator.py ru
Ошибки пишутся в translator.log рядом со скриптом.
"""
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import websocket  # pip install websocket-client

# при запуске через pyw нет консоли, print не должен падать
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")

PORT = 9222
LANG = sys.argv[1] if len(sys.argv) > 1 else "ru"
BASE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BASE, "translator.log")
CACHE_FILE = os.path.join(BASE, "translator_cache.json")

# ---------------- JS, который внедряется в лаунчер ----------------
JS = r"""
(() => {
  if (window.__mtLoaded) return;
  window.__mtLoaded = true;
  const LANG = '__LANG__';
  const SEL = '.markdown-body, .markdown, [class*="markdown"]';
  const SKIP = new Set(['CODE','PRE','KBD','SCRIPT','STYLE','SAMP','TEXTAREA']);
  const pending = new Map();
  const originals = new WeakMap();
  let nextId = 1;
  let auto = true;

  window.__mtResolve = (id, results, err) => {
    const p = pending.get(id);
    if (!p) return;
    pending.delete(id);
    err ? p.rej(new Error(err)) : p.res(results);
  };

  function trBatch(texts) {
    return new Promise((res, rej) => {
      const id = nextId++;
      pending.set(id, { res, rej });
      window.mtTranslate(JSON.stringify({ id, texts }));
    });
  }

  function findContainers() {
    let list = [...document.querySelectorAll(SEL)];
    list = list.filter((el) => !list.some((o) => o !== el && o.contains(el)));
    if (list.length) return list;
    // запасной вариант: родитель с наибольшим числом абзацев <p>
    const counts = new Map();
    document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, blockquote').forEach((p) => {
      const par = p.parentElement;
      if (par) counts.set(par, (counts.get(par) || 0) + 1);
    });
    let best = null, max = 1;
    counts.forEach((c, el) => { if (c > max) { max = c; best = el; } });
    return best ? [best] : [];
  }

  function textNodes(root) {
    const out = [];
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!/\p{L}/u.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        for (let p = n.parentElement; p && p !== root; p = p.parentElement) {
          if (SKIP.has(p.tagName)) return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (w.nextNode()) out.push(w.currentNode);
    return out;
  }

  function hasNewNodes(el) {
    return textNodes(el).some((n) => !originals.has(n));
  }

  async function translate(el) {
    if (el.dataset.mt === 'busy') return;
    el.dataset.mt = 'busy';
    updateBtn();
    const items = [];
    for (const n of textNodes(el)) {
      // уже переведённый узел пропускаем
      if (originals.has(n) && n.nodeValue !== originals.get(n)) continue;
      const src = n.nodeValue;
      if (!originals.has(n)) originals.set(n, src);
      const core = src.trim().replace(/\s*\n\s*/g, ' ');
      if (!core) continue;
      items.push({ n, lead: src.match(/^\s*/)[0], trail: src.match(/\s*$/)[0], core });
    }
    const chunks = [];
    let cur = [], len = 0;
    for (const it of items) {
      if (cur.length && (cur.length >= 30 || len + it.core.length > 2500)) {
        chunks.push(cur); cur = []; len = 0;
      }
      cur.push(it); len += it.core.length;
    }
    if (cur.length) chunks.push(cur);

    let failed = false;
    for (const ch of chunks) {
      try {
        const out = await trBatch(ch.map((x) => x.core));
        ch.forEach((x, i) => { if (out[i]) x.n.nodeValue = x.lead + out[i] + x.trail; });
      } catch (e) {
        console.warn('[MT]', e);
        failed = true;
      }
    }
    el.dataset.mt = failed ? 'err' : 'done';
    updateBtn();
    if (failed) {
      const tries = (+el.dataset.mtTry || 0) + 1;
      el.dataset.mtTry = tries;
      if (tries <= 3) setTimeout(() => {
        if (document.contains(el) && el.dataset.mt === 'err') translate(el);
      }, 20000);
    } else {
      el.dataset.mtTry = 0;
    }
  }

  function restore(el) {
    textNodes(el).forEach((n) => { if (originals.has(n)) n.nodeValue = originals.get(n); });
  }

  const start = () => {
    const btn = document.createElement('button');
    const css = {
      'position': 'fixed', 'left': '90px', 'bottom': '16px', 'z-index': '2147483647',
      'padding': '10px 14px', 'border-radius': '12px', 'border': '0', 'cursor': 'pointer',
      'font': '600 14px system-ui,sans-serif', 'color': '#fff', 'background': '#1bd96a',
      'box-shadow': '0 4px 14px rgba(0,0,0,.35)', 'display': 'block', 'pointer-events': 'auto'
    };
    for (const k in css) btn.style.setProperty(k, css[k], 'important');
    document.documentElement.appendChild(btn);

    window.updateBtn = () => {
      const list = findContainers();
      btn.style.setProperty('opacity', list.length ? '1' : '0.55', 'important');
      if (!list.length) { btn.textContent = '🌐 Жду описание…'; return; }
      const st = list[0].dataset.mt;
      btn.textContent = st === 'busy' ? '⏳ Перевожу…' :
                        st === 'done' ? '↩ Показать оригинал' :
                        st === 'err' ? '⚠ Ошибка перевода, повторить' :
                        '🌐 Перевести (' + LANG + ')';
    };

    let timer = null;
    const scan = () => {
      updateBtn();
      if (!auto) return;
      findContainers().forEach((el) => {
        const st = el.dataset.mt;
        if (st === 'busy') return;
        // содержимое блока подменили (другой мод/вкладка): начинаем заново
        if (st && hasNewNodes(el)) { delete el.dataset.mt; el.dataset.mtTry = 0; }
        if (!el.dataset.mt && el.textContent.trim()) translate(el);
      });
    };

    const toggle = async () => {
      const list = findContainers();
      if (!list.length) { scan(); return; }
      if (list[0].dataset.mt === 'done') {
        list.forEach((el) => { restore(el); el.dataset.mt = 'off'; });
        updateBtn();
      } else if (list[0].dataset.mt !== 'busy') {
        for (const el of list) await translate(el);
      }
    };

    btn.onclick = toggle;
    document.addEventListener('keydown', (e) => {
      if (e.altKey && ['t', 'T', 'е', 'Е'].includes(e.key)) { e.preventDefault(); toggle(); }
    });

    new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(scan, 600); })
      .observe(document.body, { childList: true, subtree: true });
    setInterval(scan, 3000);
    scan();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
""".replace("__LANG__", LANG)


# ---------------- Логи и кэш ----------------
def log(msg: str):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except Exception:
        pass


cache_lock = threading.Lock()
try:
    with open(CACHE_FILE, encoding="utf-8") as _f:
        cache = json.load(_f)
except Exception:
    cache = {}


def save_cache():
    with cache_lock:
        try:
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(cache, f, ensure_ascii=False)
        except Exception as e:
            log(f"cache save: {e}")


# ---------------- Переводчики ----------------
UA = {"User-Agent": "Mozilla/5.0"}


def prov_google(host):
    def run(text):
        url = (f"https://{host}/translate_a/single?client=gtx&sl=auto&dt=t&tl="
               + urllib.parse.quote(LANG))
        data = urllib.parse.urlencode({"q": text}).encode()
        req = urllib.request.Request(url, data=data, headers=UA)
        with urllib.request.urlopen(req, timeout=20) as r:
            j = json.load(r)
        return "".join(s[0] for s in j[0] if s[0])
    return run


def prov_lingva(instance):
    def run(text):
        url = f"{instance}/api/v1/auto/{urllib.parse.quote(LANG)}/{urllib.parse.quote(text, safe='')}"
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.load(r)["translation"]
    return run


PROVIDERS = [
    ("google:googleapis", prov_google("translate.googleapis.com")),
    ("google:translate.google.com", prov_google("translate.google.com")),
    ("lingva.ml", prov_lingva("https://lingva.ml")),
    ("lingva.thedaviddelta.com", prov_lingva("https://lingva.thedaviddelta.com")),
]
dead_until = {}  # имя провайдера -> время, до которого его пропускаем


def call_with_retry(fn, text):
    """Повторяет запрос с паузами при 429/5xx."""
    delay = 1.5
    for attempt in range(3):
        try:
            return fn(text)
        except urllib.error.HTTPError as e:
            if e.code == 429 or e.code >= 500:
                if attempt < 2:
                    time.sleep(delay)
                    delay *= 2
                    continue
            raise


def translate_text(text: str) -> str:
    last = None
    now = time.time()
    order = [p for p in PROVIDERS if dead_until.get(p[0], 0) <= now] or PROVIDERS
    for name, fn in order:
        try:
            return call_with_retry(fn, text)
        except Exception as e:
            last = e
            dead_until[name] = time.time() + 300  # 5 минут не трогаем неработающий
            log(f"{name}: {type(e).__name__}: {e}")
    raise last or RuntimeError("нет доступных переводчиков")


def translate_batch(texts):
    out = [None] * len(texts)
    todo = []
    for i, t in enumerate(texts):
        c = cache.get(LANG + "|" + t)
        if c is not None:
            out[i] = c
        else:
            todo.append(i)
    if todo:
        joined = "\n".join(texts[i] for i in todo)
        res = translate_text(joined)  # если все переводчики упали, исключение уйдёт в лаунчер
        parts = res.split("\n")
        if len(parts) != len(todo):
            # переводчик склеил/разбил строки: переводим по одной
            log(f"число строк не совпало ({len(parts)} != {len(todo)}), перевожу по одной")
            parts = []
            for i in todo:
                try:
                    parts.append(translate_text(texts[i]))
                except Exception as e:
                    log(f"по одной: {e}")
                    parts.append(None)
                time.sleep(0.3)
        for i, r in zip(todo, parts):
            if r:
                out[i] = r
                cache[LANG + "|" + texts[i]] = r
        save_cache()
    return out


# ---------------- CDP-подключение к лаунчеру ----------------
def find_page_ws():
    deadline = time.time() + 90  # ждём лаунчер не дольше 90 секунд
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json", timeout=3) as r:
                targets = json.load(r)
            pages = [t for t in targets if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]
            if pages:
                return pages[0]["webSocketDebuggerUrl"]
        except Exception:
            pass
        print("Жду запуск лаунчера с портом отладки…")
        time.sleep(2)
    sys.exit("Лаунчер не найден, выхожу.")


def main():
    ws_url = find_page_ws()
    ws = websocket.create_connection(ws_url, timeout=None, suppress_origin=True)
    lock = threading.Lock()
    counter = [0]

    def send(method, params=None):
        with lock:
            counter[0] += 1
            ws.send(json.dumps({"id": counter[0], "method": method, "params": params or {}}))

    send("Runtime.enable")
    send("Page.enable")
    send("Runtime.addBinding", {"name": "mtTranslate"})
    send("Page.addScriptToEvaluateOnNewDocument", {"source": JS})
    send("Runtime.evaluate", {"expression": JS})
    print(f"Переводчик подключён к лаунчеру (язык: {LANG}). Окно можно свернуть.")
    log(f"подключён, язык {LANG}")

    pool = ThreadPoolExecutor(max_workers=2)

    def handle(payload: str):
        req = json.loads(payload)
        rid = req["id"]
        try:
            res = translate_batch(req["texts"])
            expr = f"window.__mtResolve({rid}, {json.dumps(res)})"
        except Exception as e:
            log(f"batch error: {type(e).__name__}: {e}")
            expr = f"window.__mtResolve({rid}, null, {json.dumps(str(e))})"
        send("Runtime.evaluate", {"expression": expr})

    while True:
        try:
            msg = json.loads(ws.recv())
        except Exception:
            print("Лаунчер закрыт, выхожу.")
            break
        if msg.get("method") == "Runtime.bindingCalled" and msg["params"].get("name") == "mtTranslate":
            pool.submit(handle, msg["params"]["payload"])


if __name__ == "__main__":
    main()
