@echo off
chcp 65001 >nul
echo Устанавливаю зависимость...
py -m pip install websocket-client
echo Создаю ярлык...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
echo.
echo Готово. Закрой Modrinth App полностью и запускай через ярлык "Modrinth App (RU)".
pause
