"""Проверка доступности Google Translate и Modrinth из Python (без VPN).
Запуск: двойной клик или `py test_network.py`
"""
import json
import time
import urllib.parse
import urllib.request

TESTS = [
    ("Google Translate (googleapis)",
     "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q=hello",
     "translate"),
    ("Google Translate (google.com)",
     "https://translate.google.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q=hello",
     "translate"),
    ("Modrinth API",
     "https://api.modrinth.com/v2/project/fabric-api",
     "modrinth"),
    ("Modrinth CDN (картинки)",
     "https://cdn.modrinth.com/",
     "any"),
]

for name, url, kind in TESTS:
    t = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            body = r.read()
            code = r.status
        dt = time.time() - t
        extra = ""
        if kind == "translate":
            extra = " -> " + json.loads(body)[0][0][0]
        elif kind == "modrinth":
            extra = " -> " + json.loads(body).get("title", "?")
        print(f"[OK]   {name}: HTTP {code}, {dt:.1f} c{extra}")
    except Exception as e:
        dt = time.time() - t
        print(f"[FAIL] {name}: {type(e).__name__}: {e} ({dt:.1f} c)")

input("\nГотово. Нажми Enter, чтобы закрыть...")
